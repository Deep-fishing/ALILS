import torch
import torch.nn as nn
from abc import ABC


def main():

    equation_input = torch.Tensor(32, 1, 8, 25)  # [batch_size, 1, channels, time_dimension]
    equation = RGTrans()
    equation_output = equation(equation_input)
    print(equation_output.size())  # [32, 1, 25, 25]


class RGTrans(nn.Module, ABC):

    def __init__(self):
        super(RGTrans, self).__init__()
        self.trans = nn.Sequential(nn.Linear(8, 16),  # FC
                                   nn.ReLU(),
                                   nn.Linear(16, 1))

    def forward(self, x):

        out = torch.repeat_interleave(x.unsqueeze(-1), x.size(-1), dim=-1)
        out = out - out.permute(0, 1, 2, 4, 3)
        out = out.permute(0, 1, 3, 4, 2).reshape(-1, x.size(-2))
        out = self.trans(out)  # FC
        out = out.reshape(x.size()[:2] + (25, 25))

        return out


if __name__ == '__main__':
    main()
