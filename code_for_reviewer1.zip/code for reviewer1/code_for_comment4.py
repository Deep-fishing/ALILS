import torch
import torch.nn as nn
from abc import ABC


def main():
    equation_input = torch.Tensor(32, 1, 8, 25)  # batch_size, 1, channels, time_dimension
    equation = GGTrans()
    equation_output = equation(equation_input)
    print(equation_output.size())  # [32, 1, 25, 25]


class GGTrans(nn.Module, ABC):

    def __init__(self):
        super(GGTrans, self).__init__()
        self.trans = nn.Sequential(nn.Linear(200, 1024),  # FC
                                   nn.ReLU(),
                                   nn.Linear(1024, 625))

    def forward(self, x):
        out = x.reshape((-1, ) + x.size()[-2:])
        out = x.reshape(out.size(0), -1)  # Flatten
        out = self.trans(out)  # FC
        out = out.reshape(x.size()[:2] + (25, 25))  # Reshape

        return out


if __name__ == '__main__':
    main()
