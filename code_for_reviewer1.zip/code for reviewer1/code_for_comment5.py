import torch
import torch.nn as nn
from abc import ABC


def main():

    num_class = 15  # Number of load types
    model = CNN1dT2d(in_2d_channels=1, layer_list=[1, 1, 2, 4], num_class=num_class)
    model_input = torch.Tensor(32, 1, 200)  # batch_size, time_len
    model_output = model(model_input)
    print(model_output.size())  # [32, 15]


class CNN1dT2d(nn.Module, ABC):

    def __init__(self, in_2d_channels, dropout=0.5, layer_list=None, num_class=None):
        super(CNN1dT2d, self).__init__()
        self.dropout = dropout
        self.net_1d = CNN1D(in_channels=1, layer_list=layer_list)
        self.translation = RGTrans()
        self.net_2d = CNN2D(in_channels=in_2d_channels)
        self.fc = nn.Sequential(nn.Linear(64, 1024),
                                nn.ReLU(),
                                nn.Dropout(p=self.dropout),
                                nn.Linear(1024, num_class))

    def forward(self, x):

        x_1d_in = x.reshape(-1, x.size(-1)).unsqueeze(1)
        x_1d_out = self.net_1d(x_1d_in)

        x_trans_in = x_1d_out.reshape((-1, x.size(1)) + x_1d_out.size()[-2:])

        x_2d_input = self.translation(x_trans_in)
        x_2d_out = self.net_2d(x_2d_input)
        out = self.fc(x_2d_out)

        return out


class RGTrans(nn.Module, ABC):

    def __init__(self):
        super(RGTrans, self).__init__()
        self.trans = nn.Sequential(nn.Linear(8, 16),
                                   nn.ReLU(),
                                   nn.Linear(16, 1))

    def forward(self, x):

        out = torch.repeat_interleave(x.unsqueeze(-1), x.size(-1), dim=-1)
        out = out - out.permute(0, 1, 2, 4, 3)
        out = out.permute(0, 1, 3, 4, 2).reshape(-1, x.size(-2))
        out = self.trans(out)
        out = out.reshape(x.size()[:2] + (25, 25))

        return out


class CNN1D(nn.Module, ABC):
    def __init__(self, in_channels, layer_list=None):
        super(CNN1D, self).__init__()
        self.channel_list = [8, 32, 16, 8]
        self.layer1 = self._make_layer(Block, in_channels, self.channel_list[0], layer_list[0],
                                       stride=2, max_pool=True)
        self.layer2 = self._make_layer(Block, self.channel_list[0], self.channel_list[1], layer_list[1],
                                       stride=2)
        self.layer3 = self._make_layer(Block, self.channel_list[1], self.channel_list[2], layer_list[2],
                                       stride=1)
        self.layer4 = self._make_layer(Block, self.channel_list[2], self.channel_list[3], layer_list[3],
                                       stride=1)

    @staticmethod
    def _make_layer(block, in_channels, out_channels, blocks, stride=1, max_pool=None, down=None):

        if in_channels != out_channels:
            down = nn.Conv1d(in_channels, out_channels, stride=stride, kernel_size=1, bias=False)
        block_list = [block(in_channels, out_channels, stride, down)]

        for i in range(1, blocks):
            block_list.append(block(out_channels, out_channels))

        if max_pool:
            max_pool = nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
            block_list.append(max_pool)

        return nn.Sequential(*block_list)

    def forward(self, x):

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        return x


class Block(nn.Module, ABC):
    def __init__(self, in_channels, out_channels, stride=1, down=None):
        super(Block, self).__init__()
        self.in_channels = in_channels
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size=5, stride=stride, padding=2, bias=False)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU(inplace=False)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size=5, stride=1, padding=2, bias=False)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.down = down

    def forward(self, x):

        res = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.down is not None:
            res = self.down(x)

        out = out + res
        out = self.relu(out)

        return out


class CNN2D(nn.Module, ABC):
    def __init__(self, in_channels):
        super(CNN2D, self).__init__()

        self.conv0 = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=8, kernel_size=5, stride=1, padding=2),
            nn.BatchNorm2d(8),
            nn.ReLU())

        self.max_pool = nn.MaxPool2d(kernel_size=3, stride=2,  padding=1)

        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=8, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(8),
            nn.ReLU())

        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels=8, out_channels=16, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU())

        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU())

        self.conv4 = nn.Sequential(
            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU())

        self.avg2d = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        x_0 = self.conv0(x)
        x_m = self.max_pool(x_0)

        x_1 = self.conv1(x_m)

        x_2 = self.conv2(x_1)

        x_3 = self.conv3(x_2)

        x_4 = self.conv4(x_3)

        x_out = self.avg2d(x_4).squeeze(-1).squeeze(-1)
        return x_out


if __name__ == '__main__':
    main()

